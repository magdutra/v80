1. Overview

	VDK-80 is the short for "TRS-80 Virtual Disk Kit" and this program is intended to allow 
	one to perform a series of operations (read, write, rename, delete etc.) on files stored
	in a TRS-80 virtual disk image.

	A virtual disk image is simply a PC file containing a copy of an entire floppy disk. Three
	standards were developed to allow this conversion and all of them are supported by VDK-80.

	Also, the data structures inside a disk image differ from OS to OS, and VDK-80 takes those
 	differences into account, in order to allow data manipulation at file level.

	The goal of VDK-80 is to cover the entire matrix of known TRS-80 model I/III/4 Operating
	Systems. At this point in time we are very close to achieving that goal.

2. Supported Operations

	- Extract files from the disks
	- Add new files to the disks
	- Rename existing disk files
	- Delete files
	- Show the contents of a file (Hex/ASCII dump)
	- Show the contents of an entire disk (Hex/ASCII dump)

3. Supported Operating Systems

	- All known TRS-80 model I/III/4 Operating Systems are supported, except CP/M

4. Known limitations

	- Some data-only disks aren't recognized by the program
	- The program lacks a graphical interface (GUI)
	- CP/M support is still under development

	These will be improved/fixed in future versions of VDK-80.

Thank you!

Miguel Dutra
(mdutra@mdutra.com)
