#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDI_ICON                                105
